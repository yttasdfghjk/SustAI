from fastapi import APIRouter, Body, Query, Form
from typing import List, Optional
from pydantic import BaseModel

router = APIRouter()
import riskfolio as rp
import pandas as pd
import yfinance as yf
import numpy as np
import warnings

# Define a Pydantic model for the request body
class MeanVarianceRequest(BaseModel):
    tickers: List[str]
    start_date: str
    end_date: Optional[str] = "today" #fix?
    method_mu: Optional[str] = "hist"
    method_cov: Optional[str] = "hist"
    model: Optional[str] = "Classic"
    rm: Optional[str] = "MV"
    obj: Optional[str] = "Sharpe"
    rf: Optional[float] = 0
    l: Optional[float] = 0
    hist: Optional[bool] = True
    points: Optional[int] = 50

@router.post("/mean-variance")
async def mean_variance_portfolio(request: MeanVarianceRequest):
    """
    Endpoint for Mean-Variance portfolio optimization and efficient frontier calculation.
    """
    try:
        # Extract parameters from the request
        tickers = request.tickers
        start_date = request.start_date
        end_date = request.end_date
        method_mu = request.method_mu
        method_cov = request.method_cov
        model = request.model
        rm = request.rm
        obj = request.obj
        rf = request.rf
        l = request.l
        hist = request.hist
        points = request.points
        
        # For debugging/testing - override with hardcoded values
        # tickers = ["MSFT", "TSLA"]
        # start_date = "2024-01-01"
        # end_date = "2025-01-01"

        print(tickers)
        tickers.sort()
        print(tickers)
        
        # Download data
        data = yf.download(tickers, start=start_date, end=end_date, auto_adjust=False)
        data = data.loc[:, ('Adj Close', slice(None))]
        data.columns = tickers

        # Calculate returns
        # Y = data[tickers].pct_change().dropna()
        Y = data[tickers].pct_change().bfill() #loses precision


        print(data)

        # Build portfolio object
        port = rp.Portfolio(returns=Y)

        # Estimate portfolio statistics
        port.assets_stats(method_mu=method_mu, method_cov=method_cov)

        # Optimize portfolio
        w = port.optimization(model=model, rm=rm, obj=obj, rf=rf, l=l, hist=hist)

        # Calculate efficient frontier
        frontier = port.efficient_frontier(model=model, rm=rm, points=points, rf=rf, hist=hist)

        ##todos
        #round 2 decimals
        #frontier table
        #efficient frontierchart from riskfolio
        
        # Return results
        return {
            "weights": w.to_dict(),
            "frontier": frontier.to_dict(),
            "mu": port.mu.to_dict(),
            "cov": port.cov.to_dict(),
        }
    except Exception as e:
        return {"error": str(e)}

import asyncio
async def main():
    res = await mean_variance_portfolio(MeanVarianceRequest(tickers=["AAPL", "NVDA"], start_date="2016-01-01", end_date="2025-05-3"))
    if "error" in res:
        print(f"Error: {res['error']}")
    else:
        #print(res["weights"])
        #print(res["frontier"])
        #print(res["mu"])
        print(res["cov"])
        #print(res)

if __name__ == "__main__":
    asyncio.run(main())

#https://github.com/dcajasn/Riskfolio-Lib
#https://github.com/dcajasn/Riskfolio-Lib/blob/master/examples/Tutorial%201%20-%20Classic%20Mean%20Risk%20Optimization.ipynb
#https://www.google.com/search?client=firefox-b-d&sca_esv=5e8b7f57e4422f6f&q=efficient+frontier+javascript+code&udm=2&fbs=ABzOT_DDfJxgmsKFIwrWKcoyw2Rf7ED7CYyDAoRz3agYVnoe8UVw8adpCRzSzq6xx654mB8SrwXfVVO-7Tv6OBhK4S8C3f-Zbgt3_KWeEqX-sQ3aLUU3Ua62XuTpxcz1JM1IZergwPbLrAzN2MJhkqeOzLLh8dwDF-2ltDhwsYnHhtW1AGQDkG8gsII3tg2tvhWGmA6v8SOO&sa=X&ved=2ahUKEwjiqdm_soiNAxVi0gIHHfdAGpUQtKgLegQIFRAB&biw=1920&bih=947
#https://riskfolio-lib.readthedocs.io/en/latest/_modules/PlotFunctions.html#plot_frontier

#run: 
#uvicorn api.main:app --port 8080 --reload
#+pnpm run dev
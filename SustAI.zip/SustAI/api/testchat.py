import requests
import threading
import asyncio
import json

# Test the FastAPI endpoint that mimics your n8n webhook test
def test_fastapi_chat():
    url = "http://localhost:8000/api/chat"
    data = {
        "message": "Hello, how are you?",
        "user_id": "test-user"
    }
    
    try:
        response = requests.post(url, json=data)
        print("FastAPI Response Status:", response.status_code)
        print("FastAPI Response:", response.json())
    except Exception as e:
        print("FastAPI Error:", str(e))

# Your original n8n webhook test
def test_n8n_webhook():
    #url = "http://localhost:5678/webhook-test/2fc9a982-7a88-4633-8106-92fb95338269" # test url for webhook 
    url = "http://localhost:5678/webhook/2fc9a982-7a88-4633-8106-92fb95338269"
    data = {
        "chatInput": "Hello, how are you?"
    }
    
    try:
        response = requests.get(url, json=data)
        print("n8n Response Status:", response.status_code)
        print("n8n Response:", response.json())
    except Exception as e:
        print("n8n Error:", str(e))

def async_request(test_func):
    test_func()

if __name__ == "__main__":
    print("Testing FastAPI endpoint...")
    t1 = threading.Thread(target=async_request, args=(test_fastapi_chat,))
    t1.start()
    
    print("\nTesting n8n webhook directly...")
    t2 = threading.Thread(target=async_request, args=(test_n8n_webhook,))
    t2.start()
    
    # Wait for both threads to complete
    t1.join()
    t2.join()


from fastapi import FastAPI, Request, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import threading
import requests

app = FastAPI()


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # or ["*"] during development
    allow_credentials=True,
    allow_methods=["*"],  # very important for OPTIONS/POST
    allow_headers=["*"],
)


# Replace with your real webhook URL
#WEBHOOK_URL = "http://localhost:5678/webhook/2fc9a982-7a88-4633-8106-92fb95338269" #local
#WEBHOOK_URL = "https://onefirst.app.n8n.cloud/webhook/876a45b0-e8a5-4061-bf72-f0070bd6fbee" #sezo workflow
WEBHOOK_URL = "https://onefirst.app.n8n.cloud/webhook/2fc9a982-7a88-4633-8106-92fb95338269" #test

class ChatInput(BaseModel):
    chat_input: str

@app.post("/send-to-n8n")
async def send_chat_to_n8n(payload: ChatInput):
    data = {"chatInput": payload.chat_input}
    WEBHOOK_URL = "https://onefirst.app.n8n.cloud/webhook/2fc9a982-7a88-4633-8106-92fb95338269" #test

    
    try:
        response = requests.get(WEBHOOK_URL, json=data)  # use POST if n8n expects it
        response.raise_for_status()
        json_data = response.json()  # parse JSON from response
        print(json_data)
        return json_data             # return as JSON, not string
    except requests.RequestException as e:
        return {"error": str(e), "details": getattr(e.response, "text", "No response")}


@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "smishing-protection-api"}

if __name__ == "__main__":
    import uvicorn
    #uvicorn.run(app, host="0.0.0.0", port=8000)
    uvicorn.run(app, host="127.0.0.1", port=8000)

# webhook testurl:http://localhost:5678/webhook-test/2fc9a982-7a88-4633-8106-92fb95338269
# https://n8n.io/workflows/2465-building-your-first-whatsapp-chatbot/
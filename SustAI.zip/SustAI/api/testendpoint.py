import requests
r=requests.post("http://localhost:8000/send-to-n8n", json={"chat_input": "Hello, how are you?"})
print(r.json())

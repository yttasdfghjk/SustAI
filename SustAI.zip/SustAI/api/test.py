WEBHOOK_URL = "https://onefirst.app.n8n.cloud/webhook/2fc9a982-7a88-4633-8106-92fb95338269"

import requests

data = {"chatInput": "Hello, how are you?"}

response = requests.get(WEBHOOK_URL, json=data)
print(response.json())
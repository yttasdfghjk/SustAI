import requests
import threading

#url = "http://localhost:5678/webhook-test/2fc9a982-7a88-4633-8106-92fb95338269" # test url for webhook 
url = "http://localhost:5678/webhook/2fc9a982-7a88-4633-8106-92fb95338269"

data = {
    "chatInput": "Hello, how are you?"
}

"""
data = {
    "chatInput" : "Hallo, lieber Binance-Benutzer. Das neueste Inkubationsprojekt von Binance Labs, die auf der DeFi-Kette basierende Aktivität zum Münzverdienen, steht kurz vor dem Start. Es ist kein Staking erforderlich und das tägliche Einkommen beträgt bis zu 15 %. Benutzer, die an der Aktivität teilnehmen, haben auch die Möglichkeit, Airdrop-Belohnungen (1000–100.000 USDT) zu erhalten. Wenn Sie an diesem neuen Projekt interessiert sind, klicken Sie bitte auf das Bild oben, um unserer WhatsApp-Community beizutreten"
}
"""

def async_request():
    response = requests.get(url,json=data)
    print(response.json())

t = threading.Thread(target=async_request)
t.start()
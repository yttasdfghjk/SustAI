from fastapi import FastAPI, Request, BackgroundTasks
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import threading
import requests

app = FastAPI()

"""
# CORS: allow your frontend to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or use ["http://localhost:3000"] to restrict
    allow_methods=["*"],
    allow_headers=["*"],
)
"""
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # or ["*"] during development
    allow_credentials=True,
    allow_methods=["*"],  # very important for OPTIONS/POST
    allow_headers=["*"],
)


# Replace with your real webhook URL
WEBHOOK_URL = "http://localhost:5678/webhook/2fc9a982-7a88-4633-8106-92fb95338269"

class ChatInput(BaseModel):
    chat_input: str
"""
def send_to_n8n(data: dict):
    try:
        response = requests.get(WEBHOOK_URL, json=data)
        print("n8n response:", response.json())
    except Exception as e:
        print("Error sending to n8n:", str(e))

@app.post("/send-to-n8n")
async def send_chat_to_n8n(payload: ChatInput, background_tasks: BackgroundTasks):
    data = {
        "chatInput": payload.chat_input
    }
    background_tasks.add_task(send_to_n8n, data)
    return {"status": "submitted"}
"""

"""
@app.post("/send-to-n8n")
async def send_chat_to_n8n(payload: ChatInput):
    data = {"chatInput": payload.chat_input}
    
    try:
        # Use GET or POST based on how your n8n webhook is configured
        response = requests.get(WEBHOOK_URL, params=data)
        response.raise_for_status()
        print(response.json())
        return response.json()
    except requests.RequestException as e:
        return {"error": str(e), "details": getattr(e.response, "text", "No response")}
"""

"""
@app.post("/send-to-n8n")
async def send_chat_to_n8n(payload: ChatInput):
    data = {"chatInput": payload.chat_input}
    
    try:
        # Use GET or POST depending on your n8n webhook (most likely POST)
        response = requests.get(WEBHOOK_URL, params=data)
        response.raise_for_status()

        response_json = response.json()
        print(response_json)
        print(response_json["output"])
        
        # Return only the string value inside "output"
        if "output" in response_json:
            return response_json["output"]
        else:
            return {"error": "Key 'output' not found in response", "raw_response": response_json}

    except requests.RequestException as e:
        return {"error": str(e), "details": getattr(e.response, "text", "No response")}
"""


@app.post("/send-to-n8n")
async def send_chat_to_n8n(payload: ChatInput):
    data = {"chatInput": payload.chat_input}
    
    try:
        response = requests.get(WEBHOOK_URL, json=data)  # use POST if n8n expects it
        response.raise_for_status()
        json_data = response.json()  # parse JSON from response
        print(json_data)
        return json_data             # return as JSON, not string
    except requests.RequestException as e:
        return {"error": str(e), "details": getattr(e.response, "text", "No response")}


@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "smishing-protection-api"}

if __name__ == "__main__":
    import uvicorn
    #uvicorn.run(app, host="0.0.0.0", port=8000)
    uvicorn.run(app, host="127.0.0.1", port=8000)

# webhook testurl:http://localhost:5678/webhook-test/2fc9a982-7a88-4633-8106-92fb95338269
# https://n8n.io/workflows/2465-building-your-first-whatsapp-chatbot/
from fastapi import FastAPI, status
from pydantic import BaseModel
from routers import optimizer

from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.include_router(optimizer.router)

"""
origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
]
"""
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], #origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def home():
    return 

class HealthCheck(BaseModel):
    """Response model to validate and return when performing a health check."""

    status: str = "OK"


@app.get(
    "/health",
    tags=["healthcheck"],
    summary="Perform a Health Check",
    response_description="Return HTTP Status Code 200 (OK)",
    status_code=status.HTTP_200_OK,
    response_model=HealthCheck,
)

@app.get("/test")
async def test():
    return {"message": "test"}

"""
@app.get("/optimizer")
async def optimize():
    weights = {
        "30-30-40": {
            "Asset A": 10,
            "Asset B": 10,
            "Asset C": 10,            
            "Asset A": 10,
            "Asset D": 5,
            "Asset E": 5,
            "Asset F": 5,
            "Asset g": 5,
            "Asset h": 5,
            "Asset i": 5,            
            "Asset j": 10,
            "Asset k": 10,
            "Asset l": 5,
            "Asset m": 5
        
        },
    }
    return weights
"""


"""
if __name__ == '__main__':
    uvicorn.run(app, port=8080, host='0.0.0.0')
#"""
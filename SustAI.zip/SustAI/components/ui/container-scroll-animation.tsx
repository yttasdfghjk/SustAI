"use client"
//https://ui.aceternity.com/components/container-scroll-animation
//https://v0.dev/chat/open-in-v0-fgSgcfEQkjn

import React, { useRef } from "react"
import { useScroll, useTransform, motion, type MotionValue } from "motion/react"

export const ContainerScroll = ({
  titleComponent,
  children,
}: {
  titleComponent: string | React.ReactNode
  children: React.ReactNode
}) => {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
  })
// CHANGED: Added an additional state for tablet sizing and updated the effect to check for tablet size.
const [isMobile, setIsMobile] = React.useState(false)
const [isTablet, setIsTablet] = React.useState(false)

React.useEffect(() => {
  const checkSizes = () => {
    const width = window.innerWidth
    setIsMobile(width <= 800)
    // CHANGED: Treat widths between 601px and 1024px as tablet devices.
    setIsTablet(width > 800 && width <= 1024)
  }
  checkSizes()
  window.addEventListener("resize", checkSizes)
  return () => {
    window.removeEventListener("resize", checkSizes)
  }
}, [])

// CHANGED: Updated the scaling function to differentiate between mobile, tablet, and larger screens.
const scaleDimensions = () => {
  if (isMobile) {
    return [1, 1]        // No scaling changes for mobile.
  } else if (isTablet) {
    return [1.1, 1.2]    // Adjust scaling values as desired for tablets.
  } else {
    return [1.05, 1.25]  // Scaling for desktop/large screens.
  }
}


  const rotate = useTransform(scrollYProgress, [0, 1], [-30, 0])
  const scale = useTransform(scrollYProgress, [0, 1], scaleDimensions())
  const translate = useTransform(scrollYProgress, [0, 1], [0, -150])

  return (
    <div className="h-[80rem] md:h-[75rem] flex items-center justify-center relative p-2 md:p-20" ref={containerRef}>
      <div
        className="py-10 md:py-40 w-full relative"
        style={{
          perspective: "800px",
        }}
      >
        <Header translate={translate} titleComponent={titleComponent} />
        <Card rotate={rotate} translate={translate} scale={scale}>
          {children}
        </Card>
      </div>
    </div>
  )
}

export const Header = ({ translate, titleComponent }: any) => {
  return (
    <motion.div
      style={{
        translateY: translate,
      }}
      className="div max-w-5xl mx-auto text-center"
    >
      {titleComponent}
    </motion.div>
  )
}

export const Card = ({
  rotate,
  scale,
  children,
  translate, // not used in these changes but left here from the original props
}: {
  rotate: MotionValue<number>
  scale: MotionValue<number>
  translate: MotionValue<number>
  children: React.ReactNode
}) => {
  return (
    <motion.div
      style={{
        rotateX: rotate,
        scale,
      }}
      // CHANGED:
      // • Updated max-width to "max-w-7xl" (was "max-w-5xl") to give more horizontal space.
      // • Reduced height classes: from "h-[20rem] md:h-[33rem]" to "h-[16rem] md:h-[28rem]" for a shorter card.
      // • Ensured that no explicit border classes are applied (removing any heavier borders).
      // • Kept the same rounded corners "rounded-[30px]" and shadow.
      className="h-full w-full max-w-3xl mx-auto h-[2rem] md:h-[19rem] w-full p-1 md:p-1 bg-[#222222] rounded-[15px] shadow-s -mt-[145px]"
    >
      <div className="h-full w-full overflow-hidden rounded-xl rounded-[10px] bg-gray-100 md:rounded-xl md:p-0">
        {children}
      </div>
    </motion.div>
  )
}
//todo: von example source code resize class einbauen
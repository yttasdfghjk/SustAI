"use client"

import { useEffect, useRef, useState } from "react"

// Electronic component types for rendering along circuit paths
type ElectronicComponent = {
  type: "resistor" | "capacitor" | "diode" | "chip" | "node"
  x: number
  y: number
  rotation: number
  size: number
}

export default function AnimatedLines() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 })
  const [isMobile, setIsMobile] = useState(false)

  // Update dimensions on resize
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect()
        setDimensions({ width, height })
        setIsMobile(width < 768) // Set mobile state based on width
      }
    }

    // Initial measurement
    handleResize()

    // Add resize listener
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || dimensions.width === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      const { width, height } = dimensions
      const dpr = window.devicePixelRatio || 1
      canvas.width = width * dpr
      canvas.height = height * dpr
      ctx.scale(dpr, dpr)
    }

    resizeCanvas()

    // Define circuit layout based on screen size
    const width = dimensions.width
    const height = dimensions.height
    const centerX = width / 2

    // Adjust vertical spacing based on screen size
    const topY = isMobile ? 30 : 50
    const bottomY = isMobile ? 250 : 300

    // Adjust horizontal spacing based on screen size
    const cardSpacing = isMobile ? width / 3 : 300
    const leftX = centerX - cardSpacing
    const middleX = centerX
    const rightX = centerX + cardSpacing

    // Define circuit nodes (connection points) - responsive positioning
    const nodes = [
      // Center top (Powered By)
      { x: centerX - (isMobile ? 30 : 60), y: topY - 40 },
      { x: centerX, y: topY - 40 },
      { x: centerX + (isMobile ? 30 : 60), y: topY - 40 },

      // First vertical drop
      { x: centerX - (isMobile ? 30 : 60), y: topY + (isMobile ? 50 : 70) },
      { x: centerX, y: topY + (isMobile ? 50 : 70) },
      { x: centerX + (isMobile ? 30 : 60), y: topY + (isMobile ? 50 : 70) },

      // Horizontal connections
      { x: centerX - (isMobile ? width / 4 : 150), y: topY + (isMobile ? 50 : 70) },
      { x: centerX + (isMobile ? width / 4 : 150), y: topY + (isMobile ? 50 : 70) },

      // Second vertical drop
      { x: centerX - (isMobile ? width / 4 : 150), y: topY + (isMobile ? 80 : 120) },
      { x: centerX, y: topY + (isMobile ? 80 : 120) },
      { x: centerX + (isMobile ? width / 4 : 150), y: topY + (isMobile ? 80 : 120) },

      // Horizontal spread
      { x: leftX, y: topY + (isMobile ? 80 : 120) },
      { x: rightX, y: topY + (isMobile ? 80 : 120) },

      // Final vertical to cards
      { x: leftX, y: bottomY - (isMobile ? 10 : 20) },
      { x: middleX, y: bottomY - (isMobile ? 10 : 20) },
      { x: rightX, y: bottomY - (isMobile ? 10 : 20) },

      // Card connection points
      { x: leftX, y: bottomY + 30},
      { x: middleX, y: bottomY + 30},
      { x: rightX, y: bottomY + 30},
    ]

    // Define circuit connections (which nodes connect to which)
    const connections = [
      // From Powered By to first vertical
      { from: 0, to: 3, color: "cyan", width: isMobile ? 1.5 : 2 },
      { from: 1, to: 4, color: "pink", width: isMobile ? 1.5 : 2 },
      { from: 2, to: 5, color: "amber", width: isMobile ? 1.5 : 2 },

      // First horizontal connections
      { from: 3, to: 6, color: "cyan", width: isMobile ? 1.5 : 2 },
      { from: 5, to: 7, color: "amber", width: isMobile ? 1.5 : 2 },

      // Second vertical drop
      { from: 6, to: 8, color: "cyan", width: isMobile ? 1.5 : 2 },
      { from: 4, to: 9, color: "pink", width: isMobile ? 1.5 : 2 },
      { from: 7, to: 10, color: "amber", width: isMobile ? 1.5 : 2 },

      // Horizontal spread
      { from: 8, to: 11, color: "cyan", width: isMobile ? 1.5 : 2 },
      { from: 10, to: 12, color: "amber", width: isMobile ? 1.5 : 2 },

      // Final vertical to cards
      { from: 11, to: 13, color: "cyan", width: isMobile ? 1.5 : 2 },
      { from: 9, to: 14, color: "pink", width: isMobile ? 1.5 : 2 },
      { from: 12, to: 15, color: "amber", width: isMobile ? 1.5 : 2 },

      // Connect to cards
      { from: 13, to: 16, color: "cyan", width: isMobile ? 2 : 3 },
      { from: 14, to: 17, color: "pink", width: isMobile ? 2 : 3 },
      { from: 15, to: 18, color: "amber", width: isMobile ? 2 : 3 },

      // Additional cross-connections for complexity (fewer on mobile)
      ...(isMobile
        ? [{ from: 6, to: 9, color: "cyan", width: 1 }]
        : [
            { from: 6, to: 9, color: "cyan", width: 1 },
            { from: 9, to: 12, color: "pink", width: 1 },
            { from: 8, to: 14, color: "cyan", width: 1 },
          ]),
    ]

    // Define electronic components to place along the circuit - responsive sizing
    const componentScale = isMobile ? 0.7 : 1
    const components: ElectronicComponent[] = [
      // Resistors
      {
        type: "resistor",
        x: centerX - (isMobile ? 30 : 60),
        y: topY + (isMobile ? 40 : 50),
        rotation: Math.PI / 2,
        size: 15 * componentScale,
      },
      {
        type: "resistor",
        x: centerX + (isMobile ? 30 : 60),
        y: topY + (isMobile ? 40 : 50),
        rotation: Math.PI / 2,
        size: 15 * componentScale,
      },

      // Only show these on desktop
      ...(isMobile
        ? []
        : [
            { type: "resistor", x: centerX - 100, y: topY + 70, rotation: 0, size: 15 },
            { type: "resistor", x: centerX + 100, y: topY + 70, rotation: 0, size: 15 },
          ]),

      // Capacitors
      {
        type: "capacitor",
        x: centerX,
        y: topY + (isMobile ? 40 : 50),
        rotation: Math.PI / 2,
        size: 12 * componentScale,
      },
      {
        type: "capacitor",
        x: leftX,
        y: topY + (isMobile ? 100 : 150),
        rotation: Math.PI / 2,
        size: 12 * componentScale,
      },
      {
        type: "capacitor",
        x: rightX,
        y: topY + (isMobile ? 100 : 150),
        rotation: Math.PI / 2,
        size: 12 * componentScale,
      },

      // Diodes
      {
        type: "diode",
        x: leftX,
        y: bottomY - (isMobile ? 40 : 60),
        rotation: Math.PI / 2,
        size: 15 * componentScale,
      },
      {
        type: "diode",
        x: middleX,
        y: bottomY - (isMobile ? 40 : 60),
        rotation: Math.PI / 2,
        size: 15 * componentScale,
      },
      {
        type: "diode",
        x: rightX,
        y: bottomY - (isMobile ? 40 : 60),
        rotation: Math.PI / 2,
        size: 15 * componentScale,
      },

      // Chips - fewer on mobile
      ...(isMobile
        ? [
            {
              type: "chip",
              x: centerX - width / 4,
              y: topY + 65,
              rotation: 0,
              size: 20 * componentScale,
            },
          ]
        : [
            { type: "chip", x: centerX - 150, y: topY + 95, rotation: 0, size: 25 },
            { type: "chip", x: centerX + 150, y: topY + 95, rotation: 0, size: 25 },
          ]),

      // Additional nodes
      {
        type: "node",
        x: centerX - (isMobile ? width / 4 : 150),
        y: topY + (isMobile ? 80 : 120),
        rotation: 0,
        size: isMobile ? 4 : 6,
      },
      {
        type: "node",
        x: centerX + (isMobile ? width / 4 : 150),
        y: topY + (isMobile ? 80 : 120),
        rotation: 0,
        size: isMobile ? 4 : 6,
      },
      {
        type: "node",
        x: centerX,
        y: topY + (isMobile ? 80 : 120),
        rotation: 0,
        size: isMobile ? 4 : 6,
      },
    ]

    // Animation variables
    let animationFrame: number
    let time = 0
    const particles: Array<{
      x: number
      y: number
      size: number
      speed: number
      progress: number
      color: string
      connectionIndex: number
      pulse: number
      alpha: number
    }> = []

    // Function to draw electronic components
    const drawComponent = (component: ElectronicComponent) => {
      const { type, x, y, rotation, size } = component

      ctx.save()
      ctx.translate(x, y)
      ctx.rotate(rotation)

      switch (type) {
        case "resistor":
          // Draw resistor
          ctx.strokeStyle = "#666"
          ctx.lineWidth = isMobile ? 1.5 : 2
          ctx.beginPath()
          ctx.moveTo(-size, 0)
          ctx.lineTo(-size / 2, 0)

          // Zigzag pattern
          const zigHeight = size / 3
          ctx.lineTo(-size / 3, -zigHeight)
          ctx.lineTo(-size / 6, zigHeight)
          ctx.lineTo(0, -zigHeight)
          ctx.lineTo(size / 6, zigHeight)
          ctx.lineTo(size / 3, -zigHeight)

          ctx.lineTo(size / 2, 0)
          ctx.lineTo(size, 0)
          ctx.stroke()
          break

        case "capacitor":
          // Draw capacitor
          ctx.strokeStyle = "#666"
          ctx.lineWidth = isMobile ? 1.5 : 2
          ctx.beginPath()

          // Left plate
          ctx.moveTo(-size, -size / 2)
          ctx.lineTo(-size / 3, -size / 2)
          ctx.lineTo(-size / 3, size / 2)
          ctx.lineTo(-size, size / 2)

          // Right plate
          ctx.moveTo(size, -size / 2)
          ctx.lineTo(size / 3, -size / 2)
          ctx.lineTo(size / 3, size / 2)
          ctx.lineTo(size, size / 2)

          ctx.stroke()
          break

        case "diode":
          // Draw diode
          ctx.strokeStyle = "#666"
          ctx.fillStyle = "#666"
          ctx.lineWidth = isMobile ? 1.5 : 2

          // Triangle
          ctx.beginPath()
          ctx.moveTo(0, -size / 2)
          ctx.lineTo(0, size / 2)
          ctx.lineTo(-size, 0)
          ctx.closePath()
          ctx.fill()

          // Line
          ctx.beginPath()
          ctx.moveTo(0, -size / 2)
          ctx.lineTo(0, size / 2)
          ctx.lineTo(size, size / 2)
          ctx.lineTo(size, -size / 2)
          ctx.lineTo(0, -size / 2)
          ctx.stroke()
          break

        case "chip":
          // Draw IC chip
          ctx.fillStyle = "#333"
          ctx.strokeStyle = "#666"
          ctx.lineWidth = 1

          // Chip body
          ctx.fillRect(-size, -size / 2, size * 2, size)
          ctx.strokeRect(-size, -size / 2, size * 2, size)

          // Pins
          const pinCount = isMobile ? 6 : 8
          const pinWidth = (size * 2) / (pinCount + 1)

          for (let i = 0; i < pinCount / 2; i++) {
            // Top pins
            ctx.fillRect(-size + (i + 1) * pinWidth, -size / 2 - 5, 2, 5)

            // Bottom pins
            ctx.fillRect(-size + (i + 1) * pinWidth, size / 2, 2, 5)
          }

          // Notch
          ctx.beginPath()
          ctx.arc(-size + size / 4, -size / 2, size / 8, Math.PI, 0, true)
          ctx.fill()
          break

        case "node":
          // Draw connection node
          ctx.fillStyle = "#666"
          ctx.beginPath()
          ctx.arc(0, 0, size, 0, Math.PI * 2)
          ctx.fill()

          // Add highlight
          ctx.fillStyle = "#999"
          ctx.beginPath()
          ctx.arc(0, 0, size / 2, 0, Math.PI * 2)
          ctx.fill()
          break
      }

      ctx.restore()
    }

    const createParticle = (connectionIndex: number) => {
      const connection = connections[connectionIndex]
      const color = connection.color

      particles.push({
        x: nodes[connection.from].x,
        y: nodes[connection.from].y,
        size: Math.random() * (isMobile ? 1.5 : 2) + (isMobile ? 0.5 : 1),
        speed: Math.random() * 0.5 + (isMobile ? 0.4 : 0.3), // Slightly faster on mobile
        progress: 0,
        color,
        connectionIndex,
        pulse: Math.random() * Math.PI * 2, // Random phase for pulsing
        alpha: 0.8 + Math.random() * 0.2,
      })
    }

    // Create initial particles - fewer on mobile
    const initialParticleCount = isMobile ? connections.length : connections.length * 2
    for (let i = 0; i < initialParticleCount; i++) {
      // Create particles distributed across connections
      createParticle(i % connections.length)
    }

    const animate = () => {
      ctx.clearRect(0, 0, width, height)

      // Draw circuit grid background - larger grid on mobile
      const gridSize = isMobile ? 30 : 20
      ctx.strokeStyle = "rgba(255, 255, 255, 0.03)"
      ctx.lineWidth = 1

      for (let x = 0; x < width; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, height)
        ctx.stroke()
      }

      for (let y = 0; y < height; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(width, y)
        ctx.stroke()
      }

      // Draw circuit connections
      connections.forEach((connection) => {
        const fromNode = nodes[connection.from]
        const toNode = nodes[connection.to]

        // Draw the base circuit line
        ctx.beginPath()
        ctx.moveTo(fromNode.x, fromNode.y)
        ctx.lineTo(toNode.x, toNode.y)
        ctx.strokeStyle = "#333"
        ctx.lineWidth = connection.width
        ctx.stroke()

        // Draw a subtle glow effect
        ctx.beginPath()
        ctx.moveTo(fromNode.x, fromNode.y)
        ctx.lineTo(toNode.x, toNode.y)

        const glowColor =
          connection.color === "cyan"
            ? "rgba(6, 182, 212, 0.15)"
            : connection.color === "pink"
              ? "rgba(219, 39, 119, 0.15)"
              : "rgba(245, 158, 11, 0.15)"

        ctx.strokeStyle = glowColor
        ctx.lineWidth = connection.width + (isMobile ? 3 : 4)
        ctx.stroke()
      })

      // Draw electronic components
      components.forEach(drawComponent)

      // Draw nodes with pulsing effect
      nodes.forEach((node, index) => {
        // Base node
        ctx.beginPath()
        ctx.arc(node.x, node.y, isMobile ? 3 : 4, 0, Math.PI * 2)
        ctx.fillStyle = "#444"
        ctx.fill()

        // Pulsing glow for important nodes (card connections)
        if (index >= 16) {
          // Card connection nodes
          const pulseSize = (isMobile ? 3 : 4) + Math.sin(time * 3 + index) * (isMobile ? 1.5 : 2)
          const alpha = 0.3 + Math.sin(time * 3 + index) * 0.2

          let glowColor
          if (index === 16) glowColor = `rgba(6, 182, 212, ${alpha})`
          else if (index === 17) glowColor = `rgba(219, 39, 119, ${alpha})`
          else glowColor = `rgba(245, 158, 11, ${alpha})`

          ctx.beginPath()
          ctx.arc(node.x, node.y, pulseSize, 0, Math.PI * 2)
          ctx.fillStyle = glowColor
          ctx.fill()
        }
      })

      // Randomly create new particles - less frequently on mobile
      if (Math.random() < (isMobile ? 0.05 : 0.1)) {
        const connectionIndex = Math.floor(Math.random() * connections.length)
        createParticle(connectionIndex)
      }

      // Update and draw particles
      particles.forEach((particle, index) => {
        const connection = connections[particle.connectionIndex]
        const fromNode = nodes[connection.from]
        const toNode = nodes[connection.to]

        // Update position along the line
        particle.progress += particle.speed / 100

        if (particle.progress >= 1) {
          // Check if there's a next connection to follow
          const nextConnections = connections.filter((conn) => conn.from === connection.to)

          if (nextConnections.length > 0) {
            // Choose a random next connection
            const nextConnection = nextConnections[Math.floor(Math.random() * nextConnections.length)]
            const nextConnectionIndex = connections.findIndex(
              (conn) => conn.from === nextConnection.from && conn.to === nextConnection.to,
            )

            // Reset progress and update connection
            particle.progress = 0
            particle.connectionIndex = nextConnectionIndex
          } else {
            // Remove particle if no next connection
            particles.splice(index, 1)
            return
          }
        }

        // Calculate position along the line
        particle.x = fromNode.x + (toNode.x - fromNode.x) * particle.progress
        particle.y = fromNode.y + (toNode.y - fromNode.y) * particle.progress

        // Pulsing effect
        particle.pulse += 0.1
        const pulseScale = 0.8 + Math.sin(particle.pulse) * 0.2

        // Draw particle
        let gradient
        const particleWidth = (isMobile ? 20 : 30) * pulseScale
        const particleHeight = (isMobile ? 2 : 3) * pulseScale

        // Adjust gradient direction based on line direction
        const dx = toNode.x - fromNode.x
        const dy = toNode.y - fromNode.y
        const angle = Math.atan2(dy, dx)

        ctx.save()
        ctx.translate(particle.x, particle.y)
        ctx.rotate(angle)

        switch (particle.color) {
          case "cyan":
            gradient = ctx.createLinearGradient(-particleWidth / 2, 0, particleWidth / 2, 0)
            gradient.addColorStop(0, "rgba(6, 182, 212, 0)")
            gradient.addColorStop(0.5, `rgba(6, 182, 212, ${particle.alpha})`)
            gradient.addColorStop(1, "rgba(6, 182, 212, 0)")
            break
          case "pink":
            gradient = ctx.createLinearGradient(-particleWidth / 2, 0, particleWidth / 2, 0)
            gradient.addColorStop(0, "rgba(219, 39, 119, 0)")
            gradient.addColorStop(0.5, `rgba(219, 39, 119, ${particle.alpha})`)
            gradient.addColorStop(1, "rgba(219, 39, 119, 0)")
            break
          case "amber":
            gradient = ctx.createLinearGradient(-particleWidth / 2, 0, particleWidth / 2, 0)
            gradient.addColorStop(0, "rgba(245, 158, 11, 0)")
            gradient.addColorStop(0.5, `rgba(245, 158, 11, ${particle.alpha})`)
            gradient.addColorStop(1, "rgba(245, 158, 11, 0)")
            break
        }

        ctx.fillStyle = gradient || "white"
        ctx.fillRect(-particleWidth / 2, -particleHeight / 2, particleWidth, particleHeight)

        // Add a small bright center
        const centerColor =
          particle.color === "cyan"
            ? "rgba(6, 182, 212, 1)"
            : particle.color === "pink"
              ? "rgba(219, 39, 119, 1)"
              : "rgba(245, 158, 11, 1)"

        ctx.fillStyle = centerColor
        ctx.fillRect(-3, -1, 6, 2)

        ctx.restore()
      })

      // Add digital data effect at card connection points - fewer on mobile
      const dataPoints = [16, 17, 18] // Card connection node indices

      dataPoints.forEach((nodeIndex, i) => {
        const node = nodes[nodeIndex]
        const binaryData = Math.random() > 0.5 ? "1" : "0"

        // Only show occasionally for a blinking effect - less frequently on mobile
        if (Math.random() > (isMobile ? 0.8 : 0.7)) {
          let dataColor
          if (i === 0) dataColor = "rgba(6, 182, 212, 0.8)"
          else if (i === 1) dataColor = "rgba(219, 39, 119, 0.8)"
          else dataColor = "rgba(245, 158, 11, 0.8)"

          ctx.font = `bold ${isMobile ? 10 : 12}px monospace`
          ctx.fillStyle = dataColor
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(binaryData, node.x, node.y - (isMobile ? 12 : 15))
        }
      })

      time += 0.01
      animationFrame = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      cancelAnimationFrame(animationFrame)
    }
  }, [dimensions, isMobile])

  return (
    <div ref={containerRef} className="relative w-full" style={{ height: isMobile ? "250px" : "350px" }}>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />
    </div>
  )
}
"use client"

import { useEffect, useRef, useState } from "react"
import { ArrowUpRight, BarChart, PieChartIcon as ChartPie, Microscope } from "lucide-react"

interface TechnologyCardProps {
  title: string
  description: string
  color: "cyan" | "pink" | "amber"
  icon: "chart-pie" | "bar-chart" | "microscope"
  className?: string
}

export default function TechnologyCard({ title, description, color, icon, className = "" }: TechnologyCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const cardRef = useRef<HTMLDivElement>(null)

  // Check if mobile on mount and resize
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    // Initial check
    checkMobile()

    // Add resize listener
    window.addEventListener("resize", checkMobile)

    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [])

  const getIconColor = () => {
    switch (color) {
      case "cyan":
        return "text-cyan-400"
      case "pink":
        return "text-pink-400"
      case "amber":
        return "text-amber-400"
      default:
        return "text-white"
    }
  }

  const getIcon = () => {
    // Adjust icon size based on screen size
    const iconSize = isMobile ? "w-8 h-8" : "w-10 h-10"

    switch (icon) {
      case "chart-pie":
        return <ChartPie className={`${iconSize} ${getIconColor()}`} />
      case "bar-chart":
        return <BarChart className={`${iconSize} ${getIconColor()}`} />
      case "microscope":
        return <Microscope className={`${iconSize} ${getIconColor()}`} />
      default:
        return null
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resizeCanvas = () => {
      const { width, height } = canvas.getBoundingClientRect()
      canvas.width = width
      canvas.height = height
    }

    window.addEventListener("resize", resizeCanvas)
    resizeCanvas()

    let animationFrame: number
    let time = 0

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Only draw animation when hovered
      if (isHovered) {
        // Get color based on prop
        let baseColor
        switch (color) {
          case "cyan":
            baseColor = "6, 182, 212"
            break
          case "pink":
            baseColor = "219, 39, 119"
            break
          case "amber":
            baseColor = "245, 158, 11"
            break
          default:
            baseColor = "255, 255, 255"
        }

        // Draw animated border
        const borderWidth = 2
        const dashLength = 10
        const dashGap = 5
        const dashOffset = time * 30

        ctx.strokeStyle = `rgba(${baseColor}, 0.8)`
        ctx.lineWidth = borderWidth
        ctx.setLineDash([dashLength, dashGap])
        ctx.lineDashOffset = -dashOffset

        ctx.strokeRect(0, 0, canvas.width, canvas.height)

        // Draw corner glows
        const cornerSize = 20
        const corners = [
          { x: 0, y: 0 },
          { x: canvas.width, y: 0 },
          { x: canvas.width, y: canvas.height },
          { x: 0, y: canvas.height },
        ]

        corners.forEach((corner, i) => {
          const gradient = ctx.createRadialGradient(corner.x, corner.y, 0, corner.x, corner.y, cornerSize)

          gradient.addColorStop(0, `rgba(${baseColor}, ${0.3 + Math.sin(time * 3 + i) * 0.2})`)
          gradient.addColorStop(1, `rgba(${baseColor}, 0)`)

          ctx.fillStyle = gradient
          ctx.fillRect(corner.x - cornerSize, corner.y - cornerSize, cornerSize * 2, cornerSize * 2)
        })

        // Draw data particles
        for (let i = 0; i < 5; i++) {
          const x = Math.random() * canvas.width
          const y = Math.random() * canvas.height
          const size = Math.random() * 3 + 1

          ctx.beginPath()
          ctx.arc(x, y, size, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(${baseColor}, ${Math.random() * 0.5 + 0.3})`
          ctx.fill()
        }
      }

      time += 0.01
      animationFrame = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resizeCanvas)
      cancelAnimationFrame(animationFrame)
    }
  }, [isHovered, color])

  return (
    <div
      ref={cardRef}
      className={`relative bg-zinc-900 rounded-lg border border-zinc-800 hover:border-zinc-700 transition-all duration-300 ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        // Ensure minimum height for mobile view
        minHeight: isMobile ? "100px" : "auto",
        // Use aspect ratio for consistent sizing on mobile
        aspectRatio: isMobile ? "1/1" : "auto",
        maxHeight: "240px",
      }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none rounded-lg" />

      <div className={`relative z-10 h-full flex flex-col ${isMobile ? "justify-center items-center p-2" : "p-6"}`}>
        {/* Icon is always visible */}
        <div className={`${isMobile ? "mb-0" : "mb-6"} text-white`}>{getIcon()}</div>

        {/* Title and description only visible on non-mobile */}
        {!isMobile && (
          <>
            <div className="flex items-center gap-2 mb-3">
              <h3 className="text-xl font-semibold text-white">{title}</h3>
              <ArrowUpRight className="w-4 h-4 text-white" />
            </div>
            <p className="text-zinc-400 text-white">{description}</p>
          </>
        )}
      </div>

      {/* Animated highlight on hover */}
      <div
        className={`absolute inset-0 rounded-lg transition-opacity duration-300 pointer-events-none ${
          isHovered ? "opacity-100" : "opacity-0"
        }`}
        style={{
          background: `radial-gradient(circle at center, ${
            color === "cyan"
              ? "rgba(6, 182, 212, 0.15)"
              : color === "pink"
                ? "rgba(219, 39, 119, 0.15)"
                : "rgba(245, 158, 11, 0.15)"
          } 0%, transparent 70%)`,
        }}
      />
    </div>
  )
}

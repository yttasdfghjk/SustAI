import { MacbookScroll } from "@/components/ui/macbook-scroll"
import Link from "next/link"

export default function MacbookScrollDemo() {
  // Array of images to transition between
  const images = [
    "/linear.webp",
    "/test1.png",
  ]

  return (
    <div className="overflow-hidden dark:bg-[#0B0B0F] bg-white w-full">
      <MacbookScroll
        title={            
        <span>
          Unleash <br /> 
          Secure Communication
        </span>
        }
        images={images}
        showGradient={false}
      />
    </div>
  )
}


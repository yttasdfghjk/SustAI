import { Button } from '@/components/ui/button';
import { ArrowRight, CreditCard, Database } from 'lucide-react';
import { Terminal } from './terminal';
import { ContainerScroll } from "@/components/ui/container-scroll-animation";
import Image from "next/image";
import TechnologyCard from "@/components/ui/technology-card";
import AnimatedLines from "@/components/ui/animated-lines";
import Link from "next/link";
import MacbookScroll from "@/components/macbook-scroll-component"
import LandingPageDisplay from '@/components/landing-page';
import AnimatedPin from "@/components/3d-pin-comp"

export default function HomePage() {
  return (
    <main>
      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8">
            <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
              <h1 className="text-4xl font-bold text-gray-900 tracking-tight sm:text-5xl md:text-6xl">
                Protect Your Conversations
                <span className="block text-teal-500">From Phishing Threats</span>
              </h1>
              <p className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-xl lg:text-lg xl:text-xl">
                Our AI-powered phishing detection system scans your messages across platforms, flags suspicious content, and provides clear reasoning to help you stay safe online.
              </p>
              <div className="mt-8 sm:max-w-lg sm:mx-auto sm:text-center lg:text-left lg:mx-0">
                <a href="https://d4t-e2h8.onrender.com/" target="_blank">
                  <Button
                    size="lg"
                    variant="outline"
                    className="text-lg rounded-full"
                  >
                    Try It Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </a>
              </div>
            </div>
            <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
              <Terminal />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-3 lg:gap-8">
            <div>
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                <svg viewBox="0 0 24 24" className="h-6 w-6">
                  <path
                    fill="currentColor"
                    d="M14.23 12.004a2.236..."
                  />
                </svg>
              </div>
              <div className="mt-5">
                <h2 className="text-lg font-medium text-gray-900">
                  Cross-Platform Protection
                </h2>
                <p className="mt-2 text-base text-gray-500">
                  Monitor and detect phishing attempts across messaging apps like WhatsApp, Telegram, Gmail, and more.
                </p>
              </div>
            </div>

            <div className="mt-10 lg:mt-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                <Database className="h-6 w-6" />
              </div>
              <div className="mt-5">
                <h2 className="text-lg font-medium text-gray-900">
                  Privacy Configurations
                </h2>
                <p className="mt-2 text-base text-gray-500">
                  Choose between on-device detection, self-hosted LLMs, or secure cloud processing to match your privacy needs.
                </p>
              </div>
            </div>

            <div className="mt-10 lg:mt-0">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-teal-500 text-white">
                <CreditCard className="h-6 w-6" />
              </div>
              <div className="mt-5">
                <h2 className="text-lg font-medium text-gray-900">
                  Actionable Insights
                </h2>
                <p className="mt-2 text-base text-gray-500">
                  Get real-time alerts, inspect flagged messages, and understand why content was marked as malicious.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section className='py-16 w-full'></section>
      <section className='py-16 bg-black w-full'>
        <LandingPageDisplay></LandingPageDisplay>
      </section>

      {/* Scroll Animation */}
      <section className='py-16 bg-black w-full'>
        <MacbookScroll />
      </section>

      {/* Technology Section */}
      <section className='py-16 bg-black w-full'>
        <div className="w-full max-w-6xl mx-auto">
          <h1 className="text-4xl md:text-5xl text-white font-bold text-center mb-16">
            Built on a foundation of advanced, AI-driven threat detection
          </h1>

          <div className="relative mt-[30px] z-10">
            <div className="relative z-10 flex justify-center">
              <div className="bg-zinc-800/80 backdrop-blur-sm px-8 py-4 rounded-md border border-zinc-700 flex items-center gap-2">
                <span className="text-2xl font-medium text-zinc-300">Powered By</span>
              </div>
            </div>
            <div className="z-11 mt-30px mt-[-10]">
              <AnimatedLines />
            </div>

            <div className="mx-5 center grid grid-cols-3 md:grid-cols-3 gap-3 mt-[-19]">
              <TechnologyCard
                title="Phishing Detection Engine"
                description="Real-time AI models trained to detect evolving phishing and social engineering tactics across multiple platforms."
                color="cyan"
                icon="shield-check"
              />
              <TechnologyCard
                title="User Privacy Controls"
                description="Flexible privacy modes: run detection locally, self-hosted, or securely in the cloud to balance safety and data protection."
                color="pink"
                icon="lock"
              />
              <TechnologyCard
                title="Explainable Alerts"
                description="Provides detailed reasoning for every flagged message, enabling transparency and reducing false positives."
                color="amber"
                icon="alert-triangle"
              />
            </div>
          </div>
        </div>

        <section className='py-16 bg-black w-full mt-20'>
          <AnimatedPin></AnimatedPin>
        </section>

        <div className='mt-20 text-white'>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Image
                src={`/macbook-closed.jpeg`}
                alt="background"
                className="center bottom-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 object-cover z-1" 
                draggable={false}
                width={885}
                height={500}
              />  
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white sm:text-4xl">
                Ready to secure your messages?
              </h2>
              <p className="mt-3 max-w-3xl text-lg text-gray-500">
                Our phishing detection app gives you the tools to stay one step ahead of malicious actors—across platforms, devices, and communication channels.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
                Stay Ahead of Phishing Attacks
              </h2>
              <p className="mt-3 max-w-3xl text-lg text-gray-500">
                With dynamic detection and privacy-first design, our solution ensures that you’re always protected without sacrificing control over your data.
              </p>
            </div>
            <div className="mt-8 lg:mt-0 flex justify-center lg:justify-end">
              <a href="https://github.com/nextjs/saas-starter" target="_blank">
                <Button
                  size="lg"
                  variant="outline"
                  className="text-lg rounded-full"
                >
                  Get Started
                  <ArrowRight className="ml-3 h-6 w-6" />
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

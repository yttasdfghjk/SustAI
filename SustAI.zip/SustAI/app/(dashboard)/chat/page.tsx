'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'

export default function ChatPage() {
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<{ sender: string; text: string }[]>([])
  const [loading, setLoading] = useState(false)

  
  const sendMessage = async () => {
    if (!input.trim()) return
  
    setMessages((prev) => [...prev, { sender: 'You', text: input }])
    setLoading(true)
  
    try {
      const res = await fetch('http://localhost:8000/send-to-n8n', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_input: input }),
      })
  
      const data = await res.json()
      console.log('✅ API JSON:', data)
  
      setMessages((prev) => [
        ...prev,
        { sender: 'System', text: data.output || 'No output found' },
      ])
    } catch (err) {
      console.error('❌ API Error:', err)
      setMessages((prev) => [
        ...prev,
        { sender: 'System', text: 'Error sending message.' },
      ])
    } finally {
      setInput('')
      setLoading(false)
    }
  }
  
  
  
  
  

  return (
    <div className="flex flex-col justify-center items-center mx-[30vw] my-[30vh]">
      <h2 className="text-lg font-semibold mb-4">Phishing Detection Chat</h2>
      <div className="flex-1 border rounded-lg p-4 mb-4 overflow-y-auto bg-white shadow-sm space-y-2 w-full">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`text-sm p-2 rounded ${
              msg.sender === 'You' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
            }`}
          >
            <strong>{msg.sender}:</strong> {msg.text}
          </div>
        ))}
      </div>
      <div className="flex gap-2 w-full">
        <Input
          placeholder="Type a message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          disabled={loading}
        />
        <Button onClick={sendMessage} disabled={loading}>
          {loading ? 'Sending...' : 'Send'}
        </Button>
      </div>
    </div>
  )
}

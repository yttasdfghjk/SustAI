import { ArrowRight, Building, ChevronRight, LineChart, Users, Wallet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Link from "next/link"

export default function UseCasesPage() {
  const useCases = [
    {
      id: "enterprises",
      title: "Enterprises",
      icon: <Building className="h-5 w-5" />,
      description: "Protect organizational communication channels against phishing and social engineering attacks.",
      benefits: [
        "Real-time detection across email, chat, and collaboration platforms",
        "Flexible deployment: on-device, self-hosted, or cloud-based",
        "Compliance with data protection and regulatory requirements",
        "Detailed reporting for security and compliance teams",
      ],
      testimonial: {
        quote:
          "This platform strengthened our defense against phishing campaigns and reduced incident response times significantly. The ability to choose our preferred hosting model was essential for compliance.",
        author: "Michael Chen",
        role: "CISO, Meridian Corporation",
      },
      image: "/test1.png",
    },
    {
      id: "security-teams",
      title: "Security Teams",
      icon: <Users className="h-5 w-5" />,
      description: "Enhance SOC operations with AI-powered phishing detection and explainable alerts.",
      benefits: [
        "AI-driven detection with reasoning and explainability",
        "Seamless integration into existing SIEM/SOAR pipelines",
        "Customizable alert thresholds to reduce false positives",
        "Collaboration tools for team-based incident response",
      ],
      testimonial: {
        quote:
          "The explainable AI insights allow our analysts to understand why messages are flagged, improving confidence and accelerating response workflows.",
        author: "Sarah Johnson",
        role: "SOC Manager, Capital Security",
      },
      image: "/test1.png",
    },
    {
      id: "individuals",
      title: "Individuals",
      icon: <Wallet className="h-5 w-5" />,
      description: "Protect your personal accounts from phishing, scams, and malicious links across multiple apps.",
      benefits: [
        "Cross-platform protection (email, messaging, social media)",
        "On-device inference for maximum privacy",
        "Instant notifications and reasoning for flagged content",
        "Simple false-positive feedback loop to improve accuracy",
      ],
      testimonial: {
        quote:
          "I finally feel safe using my messaging apps. The reasoning function helps me understand why a message is suspicious, and I can decide what to do next.",
        author: "David Rodriguez",
        role: "Private User",
      },
      image: "/test1.png",
    },
    {
      id: "fintech",
      title: "FinTech Platforms",
      icon: <LineChart className="h-5 w-5" />,
      description: "Embed phishing protection directly into financial applications to safeguard customer trust.",
      benefits: [
        "API-first design for seamless platform integration",
        "White-label deployment to align with brand identity",
        "Support for compliance and financial regulations",
        "Enhanced customer trust through proactive security",
      ],
      testimonial: {
        quote:
          "Integrating phishing protection into our financial app has reduced fraud attempts and reassured our users, giving us a key competitive advantage.",
        author: "Emma Wilson",
        role: "Product Director, FinanceApp",
      },
      image: "/placeholder.svg?height=600&width=800",
    },
  ]

  return (
    <div className="bg-gradient-to-b from-white to-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold tracking-tight text-gray-900 mb-6">Use Cases</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Explore how our AI-powered phishing detection platform secures enterprises, individuals, and technology providers with flexible privacy-first deployment options.
          </p>
        </div>

        {/* Use Cases Tabs */}
        <Tabs defaultValue="enterprises" className="mb-24">
          <div className="flex justify-center mb-8">
            <TabsList className="grid grid-cols-2 md:grid-cols-4 p-1 bg-gray-100 rounded-lg">
              {useCases.map((useCase) => (
                <TabsTrigger
                  key={useCase.id}
                  value={useCase.id}
                  className="flex items-center gap-2 px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-teal-700"
                >
                  {useCase.icon}
                  <span className="hidden md:inline">{useCase.title}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {useCases.map((useCase) => (
            <TabsContent key={useCase.id} value={useCase.id} className="animate-in fade-in-50 duration-300">
              <div className="grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <div className="inline-flex items-center px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-medium mb-4">
                    <span>For {useCase.title}</span>
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">Tailored Solutions for {useCase.title}</h2>
                  <p className="text-gray-600 mb-8">{useCase.description}</p>

                  <div className="bg-white rounded-xl p-6 border border-gray-200 mb-8">
                    <h3 className="text-lg font-semibold mb-4 text-gray-900">Key Benefits</h3>
                    <ul className="space-y-3">
                      {useCase.benefits.map((benefit, i) => (
                        <li key={i} className="flex items-start">
                          <div className="flex-shrink-0 h-5 w-5 rounded-full bg-teal-100 flex items-center justify-center mr-3 mt-0.5">
                            <ChevronRight className="h-3 w-3 text-teal-600" />
                          </div>
                          <span className="text-gray-700">{benefit}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-gradient-to-r from-teal-50 to-emerald-50 rounded-xl p-6 border border-teal-100">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 text-teal-500 text-4xl font-serif mr-3">"</div>
                      <div>
                        <p className="italic text-gray-700 mb-4">{useCase.testimonial.quote}</p>
                        <div>
                          <p className="font-semibold text-gray-900">{useCase.testimonial.author}</p>
                          <p className="text-sm text-gray-600">{useCase.testimonial.role}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-r from-teal-200 to-emerald-200 rounded-2xl blur-lg opacity-30"></div>
                  <div className="relative rounded-xl overflow-hidden shadow-lg">
                    <img
                      src={useCase.image || "/test1.png"}
                      alt={`${useCase.title} dashboard`}
                      className="w-full h-auto"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                      <div className="p-6 text-white">
                        <h3 className="text-xl font-bold mb-2">Interactive Dashboard for {useCase.title}</h3>
                        <p className="text-white/80 mb-4">Customizable alerts and reporting tailored to your needs</p>
                        <Button size="sm" className="bg-white text-teal-700 hover:bg-gray-100">
                          See Demo
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        {/* CTA Section */}
        <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-12 text-center shadow-xl">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to see it in action?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Schedule a demo to see how our phishing detection platform adapts to your privacy, compliance, and security needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-teal-500 hover:bg-teal-600 text-white">
              Request Demo
            </Button>
            <Link href="/features">
              <Button size="lg" variant="outline" className="border-gray-600 text-white hover:bg-white/10">
                Explore Features
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>

        {/* Additional Resources */}
        <div className="mt-24">
          <h2 className="text-2xl font-bold text-center mb-8">Additional Resources</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Case Studies</CardTitle>
                <CardDescription>Real-world cybersecurity outcomes</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Learn how organizations and individuals strengthened their defenses against phishing using our solution.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="text-teal-600 hover:text-teal-700 p-0">
                  Read Case Studies <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Knowledge Base</CardTitle>
                <CardDescription>Guides, tutorials, and best practices</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Explore resources to deploy, configure, and optimize phishing detection with flexible privacy settings.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="text-teal-600 hover:text-teal-700 p-0">
                  Browse Resources <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Webinars</CardTitle>
                <CardDescription>Live and on-demand sessions</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Join our experts to learn about evolving phishing tactics, regulatory considerations, and AI-driven defenses.
                </p>
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="text-teal-600 hover:text-teal-700 p-0">
                  View Webinars <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

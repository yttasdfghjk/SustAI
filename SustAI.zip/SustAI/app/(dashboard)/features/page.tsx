import { Check, Sparkles, BarChart4, TrendingUp, PieChart, Brain, Search, Combine } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import Link from "next/link"

export default function FeaturesPage() {
  const features = [
    {
      icon: <BarChart4 className="h-6 w-6" />,
      name: "Cross-Channel Protection",
      description: "Unified phishing detection across enterprise communication platforms, messaging services, and collaboration tools.",
      benefits: [
        "API-based integration with major communication systems",
        "Coverage for email, chat, and business messaging apps",
        "Real-time analysis of incoming messages",
        "Consistent security policy enforcement across channels",
      ],
    },
    {
      icon: <TrendingUp className="h-6 w-6" />,
      name: "Adaptive Threat Detection",
      description: "Dynamic AI-driven models designed to evolve with emerging phishing and social engineering tactics.",
      benefits: [
        "Zero-shot, one-shot, and few-shot LLM classification",
        "Continuous adaptation to data drift and new attack vectors",
        "Multi-agent workflows for contextual decision-making",
        "Reduction of false positives with user feedback integration",
      ],
      highlighted: true,
    },
    {
      icon: <PieChart className="h-6 w-6" />,
      name: "Flexible Deployment",
      description: "Privacy-first deployment options to align with organizational requirements and regulatory frameworks.",
      benefits: [
        "On-device inference for maximum data sovereignty",
        "Self-hosted LLM clusters for enterprise control",
        "Cloud-hosted and third-party provider integration",
        "Customizable configurations for compliance adherence",
      ],
    },
    {
      icon: <Brain className="h-6 w-6" />,
      name: "Explainable AI Insights",
      description: "Transparent reasoning for flagged messages to support informed security decision-making.",
      benefits: [
        "Human-readable explanations for flagged content",
        "Contextual insights into malicious patterns",
        "Audit-ready logs for compliance and governance",
        "Decision support for SOC analysts and IT staff",
      ],
      highlighted: true,
    },
    {
      icon: <Combine className="h-6 w-6" />,
      name: "Threat Intelligence Integration",
      description: "Augment detection with external and proprietary threat intelligence for higher accuracy.",
      benefits: [
        "Integration with malware marketplaces and TI feeds",
        "Transfer learning from related security datasets",
        "Federated learning for cross-organizational improvement",
        "Data augmentation for emerging attack scenarios",
      ],
    },    
    {
      icon: <Search className="h-6 w-6" />,
      name: "Best of Breed",
      description: "Combine traditional ML-based threat detection with the flexibility of LLMs",
      benefits: [
        "Conventional ML models for robust detection",
        "LLMs for high-accuracy detection in face of evolving threats",
        "Ensemble models for optimal performance",
        "Aggregation of insights from diverse sources",
      ],
      highlighted: true,
    },
  ]

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-white to-gray-50">
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=500&width=500')] bg-center [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]"></div>
      <main className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-sm font-medium mb-6 border border-teal-100">
            <Sparkles className="h-4 w-4 mr-2" />
            <span>Intelligent Phishing Defense</span>
          </div>
          <h1 className="text-5xl font-bold tracking-tight text-gray-900 mb-6">Enterprise-Grade Security Features</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Advanced AI-driven capabilities designed to protect organizations against phishing and social engineering across multiple communication ecosystems.
          </p>
        </div>

        {/* Features Section */}
        <div className="mb-24">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Powerful Features</h2>
            <div className="h-1 w-20 bg-gradient-to-r from-teal-400 to-teal-600 mx-auto rounded-full"></div>
          </div>

          <div className="grid gap-8 lg:grid-cols-3 md:grid-cols-2">
            {features.map((feature, index) => (
              <div
                key={index}
                className={cn(
                  "relative group rounded-2xl p-8 transition-all duration-300 hover:shadow-xl",
                  feature.highlighted
                    ? "bg-gradient-to-br from-teal-500 to-teal-700 text-white"
                    : "bg-white hover:bg-gray-50 border border-gray-200",
                )}
              >
                <div className="absolute top-0 right-0 w-32 h-32 -mt-8 -mr-8 bg-gradient-to-br from-teal-100 to-transparent opacity-20 rounded-full blur-2xl"></div>

                <div
                  className={cn(
                    "flex items-center justify-center w-14 h-14 rounded-xl mb-6",
                    feature.highlighted ? "bg-white/20" : "bg-teal-50",
                  )}
                >
                  <div className={feature.highlighted ? "text-white" : "text-teal-600"}>{feature.icon}</div>
                </div>

                <h3 className={cn("text-xl font-bold mb-3", !feature.highlighted && "text-gray-900")}>
                  {feature.name}
                </h3>

                <p className={cn("mb-6 text-sm", feature.highlighted ? "text-white/80" : "text-gray-600")}>
                  {feature.description}
                </p>

                <ul className="space-y-3 mb-6">
                  {feature.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <div
                        className={cn(
                          "flex-shrink-0 h-5 w-5 rounded-full flex items-center justify-center mr-2 mt-0.5",
                          feature.highlighted ? "bg-white/20" : "bg-teal-100",
                        )}
                      >
                        <Check className={cn("h-3 w-3", feature.highlighted ? "text-white" : "text-teal-600")} />
                      </div>
                      <span className={feature.highlighted ? "text-white/90" : "text-gray-700"}>{benefit}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  variant={feature.highlighted ? "secondary" : "outline"}
                  className={cn(
                    "w-full mt-auto transition-all",
                    feature.highlighted
                      ? "bg-white text-teal-700 hover:bg-gray-100"
                      : "border-teal-200 text-teal-700 hover:bg-teal-50",
                  )}
                >
                  Learn More
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-24 text-center">
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-teal-500 to-emerald-500 rounded-2xl p-10 shadow-xl">
            <h2 className="text-3xl font-bold mb-4 text-white">Ready to strengthen your defenses?</h2>
            <p className="text-white/90 mb-8 max-w-2xl mx-auto">
              Discover how our phishing detection platform can adapt to your compliance, privacy, and security needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8 bg-white text-teal-700 hover:bg-gray-100 hover:text-teal-800">
                Schedule a Demo
              </Button>
              <Button size="lg" variant="outline" className="px-8 border-white text-teal-800">
                <Link href="/use-cases">View Use Cases</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
